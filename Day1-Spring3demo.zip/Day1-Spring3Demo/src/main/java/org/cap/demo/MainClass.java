package org.cap.demo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=
				new ClassPathXmlApplicationContext("demoBeans.xml");
		Customer customer=(Customer) context.getBean("cust");
		
		System.out.println(customer);
		
		context.registerShutdownHook();
	}

}
