package org.cap.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class TestClass {

	public static void main(String[] args) {
		//ApplicationContext context=
		AbstractApplicationContext context=
				new ClassPathXmlApplicationContext("capbeans.xml");
		//new ClassPathXmlApplicationContext("myBeans.xml");
		
		/*ApplicationContext context=
			new FileSystemXmlApplicationContext("D:\\Users\\vidavid\\Desktop\\myBeans.xml");
		*/
		/*BeanFactory context=new XmlBeanFactory(
				new ClassPathResource("myBeans.xml"));*/
		
		Customer customer=(Customer)context.getBean("cust");
		customer.setCustName("Jasmine");
		Customer customer1=(Customer)context.getBean("cust");
		
		
		System.out.println(customer);
		System.out.println(customer1);
		context.registerShutdownHook();
	}

}
