package org.cap.demo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Customer {
	
	
	private int customerId;
	private String custName;
	private Address custAddress;
	private double regFees;
	
	public Customer() {
		
	}

	
	
	public Customer(int customerId, String custName) {
		super();
		this.customerId = customerId;
		this.custName = custName;
	}



	public Customer(int customerId, String custName, Address custAddress, double regFees) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.custAddress = custAddress;
		this.regFees = regFees;
	}
	public int getCustomerId() {
		return customerId;
	}
	@Required
	public void setCustomerId(int customerId) {
		System.out.println("CustomerId: " + customerId);
		this.customerId = customerId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Address getCustAddress() {
		return custAddress;
	}
	
	@Autowired
	@Qualifier("custAddress1")
	public void setCustAddress(Address custAddress) {
		System.out.println("CustomerAddress: " + custAddress);
		this.custAddress = custAddress;
	}
	public double getRegFees() {
		return regFees;
	}
	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", custName=" + custName + ", custAddress=" + custAddress
				+ ", regFees=" + regFees + "]";
	}
	
	@PostConstruct
	public void customer_init() {
		System.out.println("Customer Bean initalized.");
	}
	
	@PreDestroy
	public void customer_destroy() {
		System.out.println("Customer Bean destroyed.");
	}
	
	

}
