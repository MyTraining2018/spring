package org.cap.dao;

import java.util.List;

import javax.sql.DataSource;

import org.cap.pojo.Employee;
import org.cap.util.EmployeeRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("employeeDao")
public class EmployeeDaoImpl implements IEmployeeDao{

	
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemp;
	
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemp=new JdbcTemplate(dataSource);
	}



	public void insertEmployee(Employee employee) {
		String sql="insert into employee(firstname,lastname,salary,email,empDob,empDoj) "
				+ "values(?,?,?,?,?,?)";
		
		jdbcTemp.update(sql, employee.getFirstName(),
				employee.getLastName(),
				employee.getSalary(),
				employee.getEmail(),
				employee.getEmpDob(),
				employee.getEmpDoj());
	}



	public List<Employee> getAllEmployees() {
		
		String sql="select * from employee";
		
		List<Employee> employees=jdbcTemp.query(sql, new EmployeeRowMapper());
		return employees;
	}



	public void deleteEmployee(int empId) {
		String sql="delete from employee where empid=?";
		
		jdbcTemp.update(sql,empId);
	}

}
