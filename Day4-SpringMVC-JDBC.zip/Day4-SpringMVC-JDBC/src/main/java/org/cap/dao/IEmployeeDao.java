package org.cap.dao;

import java.util.List;

import org.cap.pojo.Employee;

public interface IEmployeeDao {

	public void insertEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();
	
	public void deleteEmployee(int empId);
}
 