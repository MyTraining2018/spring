package org.cap.service;

import java.util.List;

import org.cap.dao.IEmployeeDao;
import org.cap.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("employeeService")
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeDao employeeDao;
	
	public void insertEmployee(Employee employee) {
		employeeDao.insertEmployee(employee);
	}

	public List<Employee> getAllEmployees() {
		
		return employeeDao.getAllEmployees();
	}

	public void deleteEmployee(int empId) {
		employeeDao.deleteEmployee(empId);
	}

}
