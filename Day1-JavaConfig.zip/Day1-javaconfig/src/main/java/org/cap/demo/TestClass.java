package org.cap.demo;

import org.cap.demo.config.MyJavConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=
				new AnnotationConfigApplicationContext(MyJavConfig.class);
		
		Customer customer= context.getBean(Customer.class);
		customer.setCustName("Jack");
		Customer customer1= context.getBean(Customer.class);
		System.out.println(customer);
		System.out.println(customer1);
	}

}
