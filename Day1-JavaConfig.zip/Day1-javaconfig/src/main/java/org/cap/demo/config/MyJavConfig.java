package org.cap.demo.config;

import org.cap.demo.Address;
import org.cap.demo.Customer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class MyJavConfig {

	@Bean
	@Scope("prototype")
	public Customer getCustomerBean() {
		Customer customer=new Customer();
		customer.setCustomerId(123);
		customer.setCustName("Tom");
		customer.setRegFees(23000);
		
		return customer;
	}
	
	@Bean
	public Address getAddressBean() {
		Address address=new Address();
		address.setDoorNo("34/S");
		address.setStreetName("XYZ st");
		address.setCity("Chennai");
		return address;
	}
	
}
