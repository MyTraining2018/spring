package org.cap.demo.boot;

import java.util.List;

import org.cap.demo.dao.EmployeeDaoImpl;
import org.cap.demo.pojo.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		
		ApplicationContext context=
				new ClassPathXmlApplicationContext("jdbcBeans.xml");
		EmployeeDaoImpl daoImpl=
				(EmployeeDaoImpl)context.getBean("empDaoImpl");
		
		
		//daoImpl.createTable();
		/*Employee employee=new Employee();
		employee.setFirstname("Kamal");
		employee.setLastname("Emi");
		employee.setSalary(2300);
		
		Employee employee2=new Employee("Emi", "Jack", 34000);
		
		
		
		daoImpl.insertEmployee(employee);
		daoImpl.insertEmployee(employee2);*/
		
		//daoImpl.deleteEmployee(3);
		
		/*List<Employee> employees= daoImpl.getAllEmployees();
		
		for(Employee employee:employees)
			System.out.println(employee);*/
		
		//String ename=daoImpl.findEmployeeName(2);
		//System.out.println(ename);
		
		/*Employee employee=daoImpl.findEmployee(2);
		System.out.println(employee);*/
		
		
		/*int count=daoImpl.countEmployees();
		System.out.println("Total Employees:" + count);*/
		
		/*String fullName= daoImpl.callProcedure(5);
		System.out.println("Employee Name:" + fullName);*/
		Employee employee=new Employee(123, "xyz", "ABC", 34000);
		daoImpl.addbonus(employee, 5);
		
	}

}
