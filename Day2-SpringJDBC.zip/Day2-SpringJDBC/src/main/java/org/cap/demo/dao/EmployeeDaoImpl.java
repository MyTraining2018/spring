package org.cap.demo.dao;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.cap.demo.pojo.Employee;
import org.cap.demo.util.EmployeeRowMapper;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
public class EmployeeDaoImpl implements IEmployeeDao {
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private PlatformTransactionManager transactionManager;
	
	private SimpleJdbcCall jdbcCall;
	
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
		
		jdbcCall=new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("findEmp");
	}
	
	
	
	

	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}





	public void createTable() {
		String sql="create table employee (empid int primary key "
				+ "auto_increment,firstname varchar(25),"
				+ "lastname varchar(25),salary numeric(8,2))";
		jdbcTemplate.execute(sql);
		System.out.println("Table Created");
		
	}

	public void insertEmployee(Employee employee) {
		String sql="insert into employee(firstname,lastname,salary) "
				+ "values (?,?,?)";
		//var...args
		jdbcTemplate.update(sql, employee.getFirstname(), 
				employee.getLastname(), employee.getSalary());
		System.out.println("Record Inserted.");
		
	}

	public void deleteEmployee(int employeeId) {
		String sql="delete from employee where empId=?";
		//Object Array as Argument
		jdbcTemplate.update(sql, new Object[] {employeeId});
		System.out.println("Record Deleted.");
	}

	public List<Employee> getAllEmployees() {
		//String sql="select * from employee";
		int employeeId=5;
		String sql="select * from employee where empId>=?";
		
		List<Employee> employees= jdbcTemplate.query(sql, 
				new EmployeeRowMapper(),new Object[] {employeeId});
		
		return employees;
	}

	public String findEmployeeName(int empId) {
		String sql="select firstname from employee where empid=?";
		
		String empName=jdbcTemplate.queryForObject(sql, String.class, empId);
		return empName;
	}

	public Employee findEmployee(int empId) {
		
		String sql="select firstname,lastname from employee where empid=?";
		List<Employee> emp=jdbcTemplate.query(sql, new Object[] {empId}, new EmployeeRowMapper());
		
		Employee employee= emp.get(0);
		
		return employee;
	}

	public int countEmployees() {
		String sql="select count(*) from employee where empid>=5";
		int count=jdbcTemplate.queryForInt(sql);
		return count;
	}

	public String callProcedure(int empid) {
		
		SqlParameterSource inputs=new MapSqlParameterSource()
				.addValue("employeeId", empid);
		
		Map<String, Object> outputs= jdbcCall.execute(inputs);
		
		String firstName=(String)outputs.get("fname");
		String lastName=(String)outputs.get("lname");
		
		
		return firstName+" " +lastName;
	}

	public void addbonus(Employee employee, int experience) {
		
		
		TransactionDefinition def=new DefaultTransactionDefinition();
		
		TransactionStatus status=null;
		try {
			status=transactionManager.getTransaction(def);
			
			String sql="insert into employee(empid,firstname,lastname,salary) "
					+ "values (?,?,?,?)";
			//var...args
			jdbcTemplate.update(sql,employee.getEmpId(),
					employee.getFirstname(), 
					employee.getLastname(),
					employee.getSalary());
			
		
		String sqlbonus="insert into empbonus values(?,?)";
		
		double bonus=0;
		if(experience>=10) {
			bonus=23000;
		}else if(experience>=5) {
			bonus=10000;
		}else {
			bonus=8000;
		}
			
		jdbcTemplate.update(sqlbonus,employee.getEmpId(),
				Double.parseDouble("asdsad"));
		
		transactionManager.commit(status);
	
		}catch (DataAccessException e) {
			System.out.println(e.getMessage());
			transactionManager.rollback(status);
		}
		
	}

}
