package org.cap.service;

import java.util.List;

import org.cap.dao.EmployeeDaoImpl;
import org.cap.dao.IEmployeeDao;
import org.cap.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("employeeService")
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeDao employeeDao;
	
	public void insertEmployee(Employee employee) {
		employeeDao.insertEmployee(employee);
	}

	public void deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		
	}

	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public String findEmployeeName(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee findEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public int countEmployees() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String callProcedure(int empid) {
		// TODO Auto-generated method stub
		return null;
	}

	public void addbonus(Employee employee, int experience) {
		// TODO Auto-generated method stub
		
	}

}
