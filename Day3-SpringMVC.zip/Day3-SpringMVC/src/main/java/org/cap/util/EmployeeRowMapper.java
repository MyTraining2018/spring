package org.cap.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.pojo.Employee;
import org.springframework.jdbc.core.RowMapper;

public class EmployeeRowMapper implements RowMapper<Employee>{

	public Employee mapRow(ResultSet rs, int count) throws SQLException {
		Employee employee=new Employee();
		//employee.setEmpId(rs.getInt("empid"));
		employee.setFirstName(rs.getString("firstname"));
		employee.setLastName(rs.getString("lastname"));
		//employee.setSalary(rs.getDouble("salary"));
		return employee;
	}

}
