package org.cap.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/emp")
public class EmployeeController {
	
	

	@RequestMapping("/searchForm")
	public String showSearchForm() {
		return "searchForm";	
	}
	
	@RequestMapping("searchEmp")
	public String findEmployee(
			//@RequestParam("empId") Integer empId
			HttpServletRequest request
			) {
		Integer empId=Integer.parseInt(request.getParameter("empId"));
		System.out.println("Employee Id:" + empId);
		return "searchForm";
	}
}
