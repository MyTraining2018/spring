package com.capgemini.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		
		ApplicationContext context=
				new ClassPathXmlApplicationContext("myBeans.xml");
		
	CollectionDemo demo=(CollectionDemo)context.getBean("collDemo");
	
	System.out.println(demo.getNames());
	System.out.println(demo.getAddresses());
	System.out.println(demo.getFruits());
	System.out.println(demo.getMaps());
	System.out.println(demo.getProperties());
	
		
	}

}
