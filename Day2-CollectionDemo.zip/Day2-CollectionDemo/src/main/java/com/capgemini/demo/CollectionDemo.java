package com.capgemini.demo;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionDemo {
	
	private List<String> names;
	private List<Address> addresses;
	private Set<String> fruits;
	private Map<Integer, String> maps;
	private Properties properties;

	
	public CollectionDemo() {
		
	}
	
	
	
	public Properties getProperties() {
		return properties;
	}



	public void setProperties(Properties properties) {
		this.properties = properties;
	}



	public Map<Integer, String> getMaps() {
		return maps;
	}



	public void setMaps(Map<Integer, String> maps) {
		this.maps = maps;
	}



	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	
	
	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	
	

	public Set<String> getFruits() {
		return fruits;
	}

	public void setFruits(Set<String> fruits) {
		this.fruits = fruits;
	}

	@Override
	public String toString() {
		return "CollectionDemo [names=" + names + "]";
	}
	
	

}
