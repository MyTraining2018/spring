package com.capgemini.demo;

public class Address {
	
	private String doorNo;
	private String StreetName;
	private String city;
	
	public Address() {
		
	}
	
	public Address(String doorNo, String streetName, String city) {
		super();
		this.doorNo = doorNo;
		StreetName = streetName;
		this.city = city;
	}
	public String getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public String getStreetName() {
		return StreetName;
	}
	public void setStreetName(String streetName) {
		StreetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", StreetName=" + StreetName + ", city=" + city + "]";
	}
	
	

}
